import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

interface AuthData {
  token: string;
  // Adicione os campos necessários para as informações do usuário, como o tipo de usuário
  // Exemplo: type: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private token: string | null;

  constructor(private http: HttpClient) {
    this.token = localStorage.getItem('token');
  }

  public getToken(): string | null {
    return this.token;
  }

  public clearToken(): void {
    this.token = null;
    localStorage.removeItem('token');
  }

  public isAuthenticated(): boolean {
    return !!this.token;
  }

  public authenticate(username: string, password: string): Observable<any> {
    const url = `${environment.apiURL}/api-token-auth/`;
    const data = { username, password };
    return this.http.post<AuthData>(url, data).pipe(map((response) => {
      this.setToken(response.token);
      // Retorna as informações do usuário após a autenticação
      // Você precisa implementar a lógica para recuperar essas informações do servidor
      return response; // Modifique conforme necessário
    }));
  }

  private setToken(value: string): void {
    this.token = value;
    localStorage.setItem('token', this.token);
  }

  // Método para retornar as informações do usuário logado
  public getUserInfo(): UserInfo | null {
    // Implemente a lógica para recuperar as informações do usuário logado aqui
    // Por exemplo, se você estiver usando localStorage para armazenar as informações do usuário:
    const userInfoString = localStorage.getItem('userInfo');
    if (userInfoString) {
      return JSON.parse(userInfoString);
    } else {
      return null;
    }
  }

}

interface UserInfo {
  type: string;
  // Defina a estrutura das informações do usuário aqui
  // Exemplo: type: string;
  // Adicione outros campos conforme necessário
}
